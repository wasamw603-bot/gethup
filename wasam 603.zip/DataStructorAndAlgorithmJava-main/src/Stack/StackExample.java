package Stack;

public class StackExample {
}
